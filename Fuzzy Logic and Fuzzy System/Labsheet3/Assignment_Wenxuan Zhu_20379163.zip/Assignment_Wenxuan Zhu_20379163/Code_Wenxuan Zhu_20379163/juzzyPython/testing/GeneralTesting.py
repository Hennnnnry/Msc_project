from juzzyPython.examples.SimpleT1FLS import SimpleT1FLS
SimpleT1FLS()