juzzyPython.similarity package
==============================

Submodules
----------

juzzyPython.similarity.JaccardSimilarity module
-----------------------------------------------

.. automodule:: juzzyPython.similarity.JaccardSimilarity
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: juzzyPython.similarity
   :members:
   :undoc-members:
   :show-inheritance:
