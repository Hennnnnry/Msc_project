juzzyPython.generic package
===========================

Submodules
----------

juzzyPython.generic.Input module
--------------------------------

.. automodule:: juzzyPython.generic.Input
   :members:
   :undoc-members:
   :show-inheritance:

juzzyPython.generic.MF\_Interface module
----------------------------------------

.. automodule:: juzzyPython.generic.MF_Interface
   :members:
   :undoc-members:
   :show-inheritance:

juzzyPython.generic.Output module
---------------------------------

.. automodule:: juzzyPython.generic.Output
   :members:
   :undoc-members:
   :show-inheritance:

juzzyPython.generic.Plot module
-------------------------------

.. automodule:: juzzyPython.generic.Plot
   :members:
   :undoc-members:
   :show-inheritance:

juzzyPython.generic.Tuple module
--------------------------------

.. automodule:: juzzyPython.generic.Tuple
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: juzzyPython.generic
   :members:
   :undoc-members:
   :show-inheritance:
