juzzyPython package
===================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   juzzyPython.examples
   juzzyPython.generalType2zSlices
   juzzyPython.generic
   juzzyPython.intervalType2
   juzzyPython.similarity
   juzzyPython.testing
   juzzyPython.type1
   juzzyPython.unitTests

Module contents
---------------

.. automodule:: juzzyPython
   :members:
   :undoc-members:
   :show-inheritance:
