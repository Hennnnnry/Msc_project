juzzyPython
===========

.. toctree::
   :maxdepth: 4

   juzzyPython
