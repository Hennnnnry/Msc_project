# Wenxuan Zhu
# 20379163

# Tool: Pycharm

# how to run Type-1 fuzzy sets and systems for case1
1. Open the "Fuzzy Inference System for Emergency Investigation.py" file
2. Delete the comment symbol from the line "SimpleT1FLS()"
3. Comment out the line "SimpleNST1FLS()"
4. Run the code

# how to change the input of temperature, headache and age in case1
1. Open the "SimpleT1FLS.py" file
2. Find the line "self.getTip()"(line 95)
3. Enter the values you want in the order of temperature, headache and age
Ps: Range of temperature (0, 60); Range of headache (0, 10); Range of age (0, 130)


# how to run non-singleton Type-1 fuzzy sets and systems for case2
1. Open the "Fuzzy Inference System for Emergency Investigation.py" file
2. Delete the comment symbol from the line "SimpleNST1FLS()"
3. Comment out the line "SimpleT1FLS()"
4. Run the code

# # how to change the input of temperature, headache and age in case2
1. Open the "SimpleNST1FLS.py" file
2. Find the line "self.getTip()"(line 103)
3. Enter the mean values you want in the order of temperature, headache and age
Ps: Range of temperature (0, 60); Range of headache (0, 10); Range of age (0, 130)