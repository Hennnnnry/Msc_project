"""
Wenxuan zhu
20379163
"""

from juzzyPython.examples.SimpleT1FLS import SimpleT1FLS
from juzzyPython.examples.SimpleNST1FLS import SimpleNST1FLS

# Type-1 fuzzy sets and systems for case1
SimpleT1FLS()

# Non-singleton Type-1 fuzzy sets and systems for case2
# SimpleNST1FLS()